source("FuzzyTOPSISVector.R")
source("FuzzyTOPSISLinear.R")


library(FuzzyTOPSISLinear)
library(FuzzyTOPSISVector)
library(dplyr)
library(hashmap)
library(collections)

# Resources:
# https://rdrr.io/cran/topsis/
# https://rdrr.io/cran/topsis/man/topsis.html

# Define Matrix
data <- read.csv("topsis_data.csv")

# Sciąga: 
# Krit A: Umiejętności.komunikacyjne
# Krit B: Wiedza
# Krit C: Czasochłonność

# Value Mapping

ValueInterpretation <- array(NA,dim = c(5, 4))
  
  dict(items = c(c(1,1,3), c(1,3,5), c(3,5,7), c(5,7,9), c(7,9,9)), 
                            keys = c("Very Low", "Low", "Average", "High", "Very High"))

ValueInterpretation$get("Average")

# Input data fuzzification

DecisionMakers <- unique(data$DecisionMaker)
DecisionMakersCount <- length(DecisionMakers)

Candidates <- unique(data$Kandydat)
CandidatesCount <- length(Candidates)

Criterias <- colnames(data[,3:length(data)])
CriteriasCount <- length(Criterias)

# Fuzzified and aggregated data

modified_data <- array(NA,dim = c(CandidatesCount, (2+(CriteriasCount*3))))
modified_data[,1] <- Candidates



data1 <- group_by(data, data$DecisionMaker)

for (i in 1:DecisionMakersCount){
  concatenate("dm" + i) <- array(NA,dim = c(CandidatesCount,CriteriasCount))
}

x <- FuzzyTOPSISVector(0)

d <- matrix(c(5.7,6.3,6.3,7.7,8.3,8,9.3,9.7,9,5,9,7,7,10,9,9,10,10,5.7,8.3,7,7.7,9.7,9, 9,10,10,8.33,9,7,9.67,10,9,10,10,10,3,7,6.3,5,9,8.3,7,10,9.7),nrow=3,ncol=15)
w <- c(0.7,0.9,1,0.9,1,1,0.77,0.93,1,0.9,1,1,0.43,0.63,0.83)
cb <- c('max','max','max','max','max')

FuzzyTOPSISLinear(d,w,cb)
